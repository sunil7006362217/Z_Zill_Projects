import { Component, OnInit } from '@angular/core';
import { HttpApiCallService } from 'src/app/services/http-api-call.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  ProductList : []
  constructor(private _api :HttpApiCallService) { 
    this._api.getProductList().subscribe( res => {
      console.log(res);
      this.ProductList = res;
      
    })
  }

  ngOnInit() {
    

  }
}
