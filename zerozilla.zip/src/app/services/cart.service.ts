import { NgIf } from '@angular/common';
import { Injectable } from '@angular/core';
import { RSA_NO_PADDING } from 'constants';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CartService {

  public cartItemList : any =[]
  public productList = new BehaviorSubject<any>([]);
  totalPrice : Number = 0;
  itemTotal : Number;
  // public search = new BehaviorSubject<string>("");
  constructor() { }
  getProducts(){
    return this.productList.asObservable();
  }
  addToCart(item : any):void{
    this.cartItemList.push(item);
    this.productList.next(this.cartItemList);
     this.getTotal(this.cartItemList)
    console.log(this.cartItemList)
    
  }

  getTotal(list){
    let getTotal = 0;
    list.map(res => {
      console.log(res.price);
      res.price = res.qty * res.price;
      getTotal =  getTotal + res.price;
      console.log(getTotal)

    })
     
  }
}
